<?php return array('dependencies' => array('jquery', 'wp-i18n'), 'version' => 'b1b661ce4cdd54518370');
