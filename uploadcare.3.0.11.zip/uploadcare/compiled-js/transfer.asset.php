<?php return array('dependencies' => array(), 'version' => '0803dbac41c51c4059be');
