<?php

class UcDeactivator
{
    public static function deactivate()
    {
    }
}
