export default { 'config': WP_UC_PARAMS }
