import TransferImages from './transfer/TransferImages';

document.addEventListener('DOMContentLoaded', () => {
    new TransferImages()
})
