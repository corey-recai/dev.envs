export default {
    'config': [
        'crop',
        'rotate',
        'mirror',
        'flip',
        'blur',
        'sharp',
        'enhance',
        'grayscale',
        'invert',
    ]
}
